#include <stdio.h>
#include <math.h>
#include <stdlib.h>


void f(double *x, double t, double* res)
{

  double GM = 39.;
  double r = pow((x[0]*x[0] + x[1]*x[1]), 3/2); 
  res[0] = x[2];
  res[1] = x[3];
  res[2] = -GM*x[0]/r; 
  res[3] = -GM*x[1]/r;
}

void rk2(double* xn, double t, double dt, double* res)
{
  double k1[4]; f(xn, t, k1);
  double xhalf[4]; 
  for(int i=0; i<4; ++i) xhalf[i] = xn[i] + k1[i]*dt/2;

  double k2[4]; f(xhalf, t+dt/2, k2);

  for(int i=0; i<4; ++i) res[i] = xn[i] + dt*k2[i];
}

int main(int argc, char** argv)
{
    double dt = atof(argv[1]);
    double time = atof(argv[2]);
    double x0 = atof(argv[3]);
    double y0 = 0; 
    double vx0 = atof(argv[4]);
    double vy0 = atof(argv[5]);


    int nstep = time/dt;
    double x[4] = {x0, y0, vx0, vy0};

    printf("%e %e %e %e %e\n", 0.0, x[0], x[1], x[2], x[3]);

for(int i=0; i<nstep; ++i)
  {
    double xf[4];
    rk2(x, i*dt, dt, xf);
    printf("%e %e %e %e %e\n", i*dt+dt, xf[0], xf[1], xf[2], xf[3]);
    for(int j=0; j<4; ++j) x[j] = xf[j];
  }

  return 0;
}
    